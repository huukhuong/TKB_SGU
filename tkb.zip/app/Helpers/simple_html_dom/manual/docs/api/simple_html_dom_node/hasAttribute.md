# hasAttribute

```php
hasAttribute ( string $name ) : bool
```

| Parameter | Description
| --------- | -----------
| `name`    | Name of the attribute.

Returns true if the current node has an attribute with the specified name.