# nodeName

```php
nodeName ( ) : string
```

Returns the name of the current node (tag name).